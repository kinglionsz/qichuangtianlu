# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Codebase Overview

This is a single-page HTML application that visualizes the 2017 骑闯天路 (Ride the Heavenly Road) cycling event in Shenzhen. The page features a cyberpunk/synthwave aesthetic with neon colors, glitch effects, and animated cycling trajectory.

## Key Components

- `index.html`: The main file containing all HTML, CSS, and JavaScript
- `bike.jpg`: Background image for the hero section
- `route-map.jpg`: Route map image displayed in the gallery
- `winner1.jpg`, `winner2.jpg`: Event photos displayed in the gallery

## Architecture and Structure

The application is a self-contained single-page app with:

1. **HTML Structure**: Semantic sections for hero, trajectory, route checkpoints, details, and gallery
2. **CSS Styling**: Extensive use of CSS variables for the neon color scheme, custom properties for animations, and responsive design with media queries
3. **JavaScript Functionality**: Canvas-based trajectory visualization with:
   - Dynamic cycling progress animation
   - Real-time telemetry display (distance, elevation, speed, time)
   - Elevation profile chart
   - Route segment labeling
   - Interactive controls (play/pause, speed adjustment, reset)

## Key Technical Details

- The trajectory visualization uses direct Canvas pixel coordinates rather than GPS-to-Canvas mapping for accuracy
- Route data is hardcoded in the `wp` array with Canvas coordinates and GPS metadata
- Animation loop runs at approximately 60fps using `requestAnimationFrame`
- Responsive design with mobile-friendly layout
- Scroll-based reveal animations using IntersectionObserver

## Development Commands

This is a static site with no build process. To develop:

1. Edit `index.html` directly
2. Open the file in a modern browser to view changes
3. No compilation or build steps are needed

## Key Files and Locations

- `index.html`: Main file containing all code
- `#trajectory-canvas`: Canvas element for the cycling trajectory visualization
- `wp` array: Contains all route waypoints with Canvas coordinates and metadata
- `route` variable: Reference to the `wp` array used by the visualization
- `progress` variable: Controls the animation progress (0.0 to 1.0)

## Important Implementation Notes

- The route visualization uses direct Canvas pixel coordinates defined in the `coastPts` and `wp` arrays
- GPS coordinates are stored as metadata for display but are not used for positioning
- The peninsula map orientation is from southwest (left) to northeast (right)
- Animation speed is controlled by the `speed` variable and `cycleSpeed()` function
- The `posAt(t)` function interpolates between waypoints for smooth animation