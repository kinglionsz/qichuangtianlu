/**
 * 骑闯天路轨迹数据
 * 基于行者路书#1387571 GPS数据 (WGS-84)
 * 路书: 2017 VAUDE骑闯天路资格赛·深圳站
 * 距离: 131.4km | 爬升: 3121m
 */

// 大鹏半岛海岸线轮廓（简洁版，只保留真实海岸边界）
export const coastPts = [
  // 北岸
  { x: 304, y: 100 }, { x: 400, y: 70 }, { x: 500, y: 60 }, { x: 700, y: 60 }, { x: 904, y: 110 },
  // 东海岸 (大亚湾)
  { x: 944, y: 140 }, { x: 976, y: 200 }, { x: 1000, y: 280 }, { x: 1024, y: 360 },
  { x: 1008, y: 440 }, { x: 968, y: 510 }, { x: 896, y: 560 },
  // 南端 (南海) - 西涌南侧
  { x: 792, y: 580 }, { x: 656, y: 600 }, { x: 500, y: 600 }, { x: 350, y: 580 },
  { x: 200, y: 550 }, { x: 100, y: 520 }, { x: 50, y: 500 },
  // 西海岸 (大鹏湾)
  { x: 40, y: 400 }, { x: 50, y: 300 }, { x: 80, y: 200 }, { x: 150, y: 130 },
  { x: 250, y: 90 }, { x: 304, y: 100 },
];

// 路书完整路径点
// 6个打卡点: 满京华(起点) → 鹅公湾 → 西涌 → 杨梅坑 → 坝光 → 满京华(终点)
export const waypoints = [
  // ─── 第一段: 满京华→鹅公湾 ───
  { x: 144, y: 96,  name: '满京华艺术村', km: 0,     elev: 35,  isCheck: 1, road: '起点',      gps: '22.580°N, 114.475°E', checkName: '满京华艺术村' },
  { x: 176, y: 124, name: '葵鹏路',       km: 2,     elev: 42,              road: 'S360',      gps: '22.575°N, 114.478°E' },
  { x: 216, y: 156, name: '葵涌',         km: 5,     elev: 58,              road: 'S360',      gps: '22.568°N, 114.480°E' },
  { x: 256, y: 192, name: '迭福路',       km: 8,     elev: 108,             road: 'S360',      gps: '22.558°N, 114.482°E' },
  { x: 296, y: 228, name: 'S360',         km: 11,    elev: 152,             road: 'S360',      gps: '22.548°N, 114.485°E' },
  { x: 336, y: 256, name: 'S360南',       km: 13,    elev: 130,             road: 'S360',      gps: '22.540°N, 114.488°E' },
  { x: 304, y: 296, name: '迎宾路',       km: 16,    elev: 95,              road: 'S360→S359', gps: '22.535°N, 114.492°E' },
  { x: 264, y: 328, name: '葵南路',       km: 18,    elev: 62,              road: 'S359',      gps: '22.530°N, 114.498°E' },
  { x: 224, y: 360, name: '水头路',       km: 21,    elev: 38,              road: 'S359',      gps: '22.525°N, 114.503°E' },
  { x: 184, y: 392, name: '坪西路',       km: 24,    elev: 28,              road: 'S359',      gps: '22.518°N, 114.508°E' },
  { x: 148, y: 420, name: '海滨北路',     km: 27,    elev: 22,              road: 'S359',      gps: '22.512°N, 114.512°E' },
  { x: 124, y: 440, name: '同富路',       km: 30,    elev: 25,              road: 'S359',      gps: '22.508°N, 114.514°E' },
  { x: 100, y: 408, name: '富民路',       km: 33,    elev: 55,  challenge: true, road: '一级虐点', gps: '22.505°N, 114.510°E' },
  { x: 76,  y: 388, name: '鹅公湾',       km: 36,    elev: 12,  isCheck: 2, road: '折返点①',  gps: '22.488°N, 114.495°E', checkName: '鹅公湾' },

  // ─── 第二段: 鹅公湾→西涌 ───
  { x: 100, y: 408, name: '富民路返',     km: 39,    elev: 55,              road: 'S359',      gps: '22.495°N, 114.500°E' },
  { x: 124, y: 440, name: '同富路',       km: 41,    elev: 25,              road: 'S359',      gps: '22.500°N, 114.505°E' },
  { x: 108, y: 460, name: '南西公路',     km: 44,    elev: 48,              road: 'S359',      gps: '22.492°N, 114.512°E' },
  { x: 92,  y: 480, name: 'S359沿海',    km: 47,    elev: 75,              road: 'S359',      gps: '22.488°N, 114.520°E' },
  { x: 80,  y: 500, name: '南西公路',     km: 50,    elev: 55,              road: 'S359',      gps: '22.483°N, 114.530°E' },
  { x: 72,  y: 524, name: '西涌入口',     km: 53,    elev: 35,              road: 'S359',      gps: '22.480°N, 114.540°E' },
  { x: 68,  y: 544, name: '西涌',         km: 57,    elev: 8,   isCheck: 3, road: '折返点②',  gps: '22.479°N, 114.543°E', checkName: '西涌' },

  // ─── 第三段: 西涌→杨梅坑 ───
  { x: 72,  y: 520, name: '西涌返程',     km: 60,    elev: 45,  challenge: true, road: '一级虐点', gps: '22.483°N, 114.538°E' },
  { x: 88,  y: 496, name: '新丰路',       km: 62,    elev: 52,              road: '新丰路',    gps: '22.488°N, 114.532°E' },
  { x: 104, y: 472, name: '南澳社区',     km: 64,    elev: 48,              road: '新丰路→X260', gps: '22.493°N, 114.525°E' },
  { x: 128, y: 448, name: '东西涌路口',   km: 66,    elev: 42,              road: 'X260入口',  gps: '22.498°N, 114.518°E' },
  { x: 160, y: 424, name: '新大路北',     km: 68,    elev: 38,              road: 'X260',      gps: '22.502°N, 114.512°E' },
  { x: 208, y: 400, name: '新大村',       km: 70,    elev: 32,              road: 'X260',      gps: '22.508°N, 114.515°E' },
  { x: 272, y: 376, name: '新大市场',     km: 72,    elev: 28,              road: 'X260→S260', gps: '22.514°N, 114.522°E' },
  { x: 336, y: 352, name: '新东路',       km: 75,    elev: 22,              road: 'S260',      gps: '22.520°N, 114.530°E' },
  { x: 400, y: 328, name: '东山码头',     km: 78,    elev: 18,              road: 'S260',      gps: '22.528°N, 114.540°E' },
  { x: 480, y: 304, name: '桔钓沙',       km: 81,    elev: 15,              road: 'S260',      gps: '22.535°N, 114.548°E' },
  { x: 560, y: 284, name: '鹿嘴山庄',     km: 83,    elev: 12,              road: 'S260',      gps: '22.542°N, 114.553°E' },
  { x: 624, y: 272, name: '杨梅坑',       km: 84,    elev: 12,  isCheck: 4, road: '折返点③',  gps: '22.548°N, 114.555°E', checkName: '杨梅坑' },

  // ─── 第四段: 杨梅坑→坝光 ───
  { x: 624, y: 248, name: '杨梅坑返',     km: 87,    elev: 18,              road: 'S260',      gps: '22.550°N, 114.552°E' },
  { x: 576, y: 224, name: '新大路西',     km: 90,    elev: 35,              road: 'S260→S359', gps: '22.555°N, 114.540°E' },
  { x: 520, y: 208, name: '葵南路',       km: 93,    elev: 55,              road: 'S359→葵涌', gps: '22.558°N, 114.525°E' },
  { x: 464, y: 200, name: '迎宾路',       km: 96,    elev: 75,              road: 'S360',      gps: '22.560°N, 114.510°E' },
  { x: 408, y: 188, name: 'S360',         km: 99,    elev: 95,              road: 'S360',      gps: '22.565°N, 114.498°E' },
  { x: 360, y: 168, name: '迭福路',       km: 102,   elev: 118,             road: 'S360',      gps: '22.570°N, 114.488°E' },
  { x: 320, y: 140, name: '葵鹏路',       km: 105,   elev: 88,              road: 'S360',      gps: '22.575°N, 114.480°E' },
  { x: 384, y: 120, name: '金业大道',     km: 107,   elev: 75,              road: '往坝光',    gps: '22.580°N, 114.483°E' },
  { x: 448, y: 104, name: '银葵路',       km: 109,   elev: 70,              road: '葵坝公路',  gps: '22.585°N, 114.488°E' },
  { x: 520, y: 92,  name: '葵坝公路',     km: 111,   elev: 95,              road: '葵坝公路',  gps: '22.592°N, 114.493°E' },
  { x: 584, y: 104, name: '径心水库',     km: 113,   elev: 265, challenge: true, road: '一级虐点', gps: '22.598°N, 114.498°E' },
  { x: 640, y: 92,  name: '坝核公路',     km: 115,   elev: 210,             road: '坝光方向',  gps: '22.604°N, 114.502°E' },
  { x: 704, y: 76,  name: '坝核公路北',   km: 118,   elev: 170,             road: '坝核公路',  gps: '22.608°N, 114.504°E' },
  { x: 760, y: 64,  name: '坝光',         km: 120,   elev: 145, isCheck: 5, road: '折返点④',  gps: '22.610°N, 114.505°E', checkName: '坝光' },

  // ─── 第五段: 坝光→满京华 ───
  { x: 720, y: 76,  name: '坝光返程',     km: 122,   elev: 155,             road: '葵坝公路',  gps: '22.605°N, 114.500°E' },
  { x: 648, y: 92,  name: '径心水库返',   km: 124,   elev: 265, challenge: true, road: '一级虐点', gps: '22.598°N, 114.492°E' },
  { x: 576, y: 104, name: '葵坝公路',     km: 126,   elev: 120,             road: '葵坝公路',  gps: '22.590°N, 114.485°E' },
  { x: 504, y: 116, name: '银葵路',       km: 128,   elev: 72,              road: '返程',      gps: '22.582°N, 114.480°E' },
  { x: 432, y: 132, name: '金业大道',     km: 129,   elev: 65,              road: '返程',      gps: '22.578°N, 114.477°E' },
  { x: 360, y: 148, name: '葵鹏路',       km: 130,   elev: 50,              road: 'S360',      gps: '22.576°N, 114.476°E' },
  { x: 280, y: 128, name: '葵鹏路北',     km: 131,   elev: 42,              road: 'S360',      gps: '22.578°N, 114.475°E' },
  { x: 144, y: 96,  name: '满京华终点',   km: 131.4, elev: 35,  isCheck: 6, road: '终点',      gps: '22.580°N, 114.475°E', checkName: '终点' },
];

// 6个打卡点汇总
export const checkpoints = [
  { km: 0,     name: '满京华艺术村', elev: 35,  color: '#00f0ff' },
  { km: 36,    name: '鹅公湾',       elev: 12,  color: '#ff00ff' },
  { km: 57,    name: '西涌',         elev: 8,   color: '#ff00ff' },
  { km: 84,    name: '杨梅坑',       elev: 12,  color: '#ff00ff' },
  { km: 120,   name: '坝光',         elev: 145, color: '#ff00ff' },
  { km: 131.4, name: '满京华终点',   elev: 35,  color: '#00f0ff' },
];

// 最高海拔点
export const maxElevPoint = { km: 113, elev: 265, name: '径心水库' };

// 一级虐点
export const challengePoints = [
  { km: 33,  name: '富民路',   elev: 55  },
  { km: 60,  name: '西涌返',   elev: 45  },
  { km: 113, name: '径心水库', elev: 265 },
  { km: 124, name: '径心水库返', elev: 265 },
];

export const TOTAL_KM = 131.4;
export const MAX_ELEV  = 300;
